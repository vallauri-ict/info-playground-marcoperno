var express = require("express");
var app = express();

app.listen(1337, function(){
    console.log("Il server è in ascolto sulla porta 1337");
});

app.get("/servizio1", function(req, res){
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods","GET, POST");
    //ATTENZIONE! ANGULAR VUOLE UN JSON SEMPRE!!!! 
    //SE MANDATE UNA STRINGA VIENE VISUALIZZATO UN ERRORE DI PARSING DELLA RISPOSTA
    res.json("Hai richiamato il servizio1");
});

app.use("/", function(req, res){
    res.send("Benvenuto nel sito");
})