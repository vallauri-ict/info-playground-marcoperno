import { Component } from "@angular/core";

@Component({
    selector:'app-dadi',
    templateUrl:'./dadi.component.html',
    styleUrls:['./dadi.component.css']
})

export class DadiComponent{
    dado1:number;
    dado2:number;
    constructor(){
        this.dado1 = Math.floor(Math.random() * 6)+1;
        this.dado2 = Math.floor(Math.random() * 6)+1;
    }
}