import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-neve',
  templateUrl: './neve.component.html',
  styleUrls: ['./neve.component.css']
})
export class NeveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
