﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Es04_GestioneUtente
{
    public partial class ScegliLibro : System.Web.UI.Page
    {
        clsDB db;
        protected void Page_Load(object sender, EventArgs e)
        {
            //la connessione al db va SEMPRE fatta
            db = new clsDB("App_Data\\Biblioteca.mdf");
            if (!Page.IsPostBack)
            {
                popolaDgvLibri();
            }
        }

        private void popolaDgvLibri()
        {
            dgvLibri.DataSource = db.caricaLibri();
            dgvLibri.DataBind();
        }
    }
}