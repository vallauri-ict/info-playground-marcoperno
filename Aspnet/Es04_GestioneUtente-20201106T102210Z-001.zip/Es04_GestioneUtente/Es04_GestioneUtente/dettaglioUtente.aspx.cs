﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Es04_GestioneUtente
{
    public partial class dettaglioUtente : System.Web.UI.Page
    {
        clsDB db;
        protected void Page_Load(object sender, EventArgs e)
        {
            //la connessione al db va SEMPRE fatta
            db = new clsDB("App_Data\\Biblioteca.mdf");
            if (Session["idUtente"] != null)
                impostaCampi(Session["idUtente"].ToString()); //la session è globale, potrei anche non passarla come parametro
            else
                Response.Redirect("Login.aspx"); //non sono autenticato
            //
        }

        private void popolaCmbRegioni()
        {
            cmbRegioni.DataSource = db.caricaRegioni();
            cmbRegioni.DataValueField = "idRegione";
            cmbRegioni.DataTextField = "Regione";
            //OBBLIGATORIO per tutti gli oggetti a cui associamo un dataSource
            cmbRegioni.DataBind();
            ListItem l = new ListItem();
            l.Value = "-1";
            l.Text = "---Selezionare Regione---";
            cmbRegioni.Items.Insert(0, l);
            //In questo modo posso gestire sempre
            //selectedindexchanged
            cmbRegioni.AutoPostBack = true;
        }
        private void popolaCmbProvince(string idRegione)
        {
            cmbProvince.DataSource = db.caricaProvince(idRegione);
            cmbProvince.DataValueField = "idProvincia";
            cmbProvince.DataTextField = "Provincia";
            cmbProvince.DataBind();
            ListItem l = new ListItem();
            l.Value = "-1";
            l.Text = "---Selezionare Provincia---";
            cmbProvince.Items.Insert(0, l);
            //In questo modo posso gestire sempre
            //selectedindexchanged
            cmbProvince.AutoPostBack = true;
        }
        private void popolaCmbComuni(string idProvincia)
        {
            cmbComuni.DataSource = db.caricaComuni(idProvincia);
            cmbComuni.DataValueField = "idComune";
            cmbComuni.DataTextField = "Comune";
            cmbComuni.DataBind();
            ListItem l = new ListItem();
            l.Value = "-1";
            l.Text = "---Selezionare Provincia---";
            cmbComuni.Items.Insert(0, l);
            //
            cmbComuni.AutoPostBack = false;
        }
        private void impostaCampi(string idUtente)
        {
            //posso richiamare un metodo che mi ritorna un dataTable oppure
            //posso utilizzare le property
            try
            {
                //DataTable dt;
                //dt = db.caricaUtente(idUtente);
                //txtCognome.Text = dt.Rows[0].ItemArray[1].ToString();
                //
                db.caricaUtente(idUtente);
                txtCognome.Text = db.Cognome;
                txtNome.Text = db.Nome;
                txtUsername.Text=db.Username;
                txtPassword.Text = ""; //ho soltanto lo sha256 e quindi non mi serve visualizzarlo
                txtDataNascita.Text = db.DataNascita;
                txtDataNascita.Text=txtDataNascita.Text.Substring(0, 10);
                //
                popolaCmbRegioni();
                cmbRegioni.SelectedValue = db.IdRegione;
                popolaCmbProvince(db.IdRegione);
                cmbProvince.SelectedValue = db.IdProvincia;
                popolaCmbComuni(db.IdProvincia);    
                cmbComuni.SelectedValue = db.IdComune;
            }
            catch (Exception ex)
            {
                lblMessaggio.Text = "ERRORE: " + ex.Message;
            }
            
        }

        protected void cmbRegioni_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbRegioni.SelectedValue == "-1")
            {
                cmbProvince.Items.Clear();
                cmbProvince.DataSource = null;
                cmbProvince.DataBind();
                cmbComuni.Items.Clear();
                cmbComuni.DataSource = null;
                cmbComuni.DataBind();
            }
            else
            {
                cmbProvince.DataSource = db.caricaProvince(cmbRegioni.SelectedValue);
                cmbProvince.DataValueField = "idProvincia";
                cmbProvince.DataTextField = "Provincia";
                cmbProvince.DataBind();
                ListItem l = new ListItem();
                l.Value = "-1";
                l.Text = "---Selezionare Provincia---";
                cmbProvince.Items.Insert(0, l);
                //In questo modo posso gestire sempre
                //selectedindexchanged
                cmbProvince.AutoPostBack = true;
            }
        }

        protected void cmbProvince_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProvince.SelectedValue == "-1")
            {
                cmbComuni.Items.Clear();
                cmbComuni.DataSource = null;
                cmbComuni.DataBind();
            }
            else
            {
                cmbComuni.DataSource = db.caricaComuni(cmbProvince.SelectedValue);
                cmbComuni.DataValueField = "idComune";
                cmbComuni.DataTextField = "Comune";
                cmbComuni.DataBind();
                ListItem l = new ListItem();
                l.Value = "-1";
                l.Text = "---Selezionare Provincia---";
                cmbComuni.Items.Insert(0, l);
                //
                cmbComuni.AutoPostBack = false;
            }
        }

        protected void btnSalva_Click(object sender, EventArgs e)
        {
            //fare UPDATE
        }
    }
}