# 05-Es Funzioni

_Prof. Diego Belliardo_


### Esercizio sull'uso delle funzioni

CREATE TABLE [Cliente] (
[IdCliente] int,
[Nome] varchar(50),
[Cognome] varchar(50),
[IdCarrello] int,
PRIMARY KEY ([IdCliente])
);
