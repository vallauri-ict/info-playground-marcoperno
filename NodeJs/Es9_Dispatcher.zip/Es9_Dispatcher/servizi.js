let disp = require("./dispatcher");

function _servizio1(req, res){
    console.log("Sono servizio 1");
    //Creo un oggetto javascript contenente la risposta del server
    disp.inviaRisposta(res, 1, "Servizio 1 intercettato");
}

function _servizio2(req, res){
    console.log("Sono servizio 2");
    //Creo un oggetto javascript contenente la risposta del server
    disp.inviaRisposta(res, 1, "Servizio 2 intercettato");
}

function _servizio3(req, res){
    console.log("Sono servizio 3");
    //Creo un oggetto javascript contenente la risposta del server
    disp.inviaRisposta(res, 1, "Servizio 3 intercettato");
}

module.exports.servizio1 = _servizio1;
module.exports.servizio2 = _servizio2;
module.exports.servizio3 = _servizio3;